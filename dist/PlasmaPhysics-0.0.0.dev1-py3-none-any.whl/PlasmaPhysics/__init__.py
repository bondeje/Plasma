# -*- coding: utf-8 -*-
"""
Created on Thu Apr  7 17:11:52 2022

@author: jeffrey bonde
"""

import sys

__all__ = ["diagnostics",
           "field",
           "ensemble",
           "fluid",
           "multifluid", 
           "particle",
           "dispersion",
           "parameters",
           "utils"]

from ._version import get_versions

vinfo = get_versions()
__version__ = vinfo["version"]
require_python = tuple(int(d) for d in vinfo["python"].split('.'))
python_version = tuple(sys.version_info)[:3]

if require_python > python_version:
    raise ImportError(f"module Plasma: requires minimum python version of {vinfo['python']}, found {'.'.join([str(d) for d in python_version])}", name="Plasma")

del get_versions, vinfo, python_version, require_python

def set_unit_system(system_name):
    pass